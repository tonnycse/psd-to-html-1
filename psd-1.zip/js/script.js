// $(document).ready(function(){
// 	$('.bar> li> a').click(function(e){
// 		e.preventDefault();
// 		$(this).parent('li').children('ul').slideToggle();
// 	});
// });